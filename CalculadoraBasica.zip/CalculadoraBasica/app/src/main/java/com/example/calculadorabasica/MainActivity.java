package com.example.calculadorabasica;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        EditText operacio1 = findViewById(R.id.operacio1);
        EditText operacio2 = findViewById(R.id.operacio2);

        Button btnSuma = findViewById(R.id.btnSuma);
        Button btnResta = findViewById(R.id.btnResta);
        Button btnMultiplicar = findViewById(R.id.btnMultiplicar);
        Button btnDividir = findViewById(R.id.btnDividir);

        TextView resultat = findViewById(R.id.Resultat);

        btnSuma.setOnClickListener(v -> {

            double numero1 = Double.parseDouble(operacio1.getText().toString());
            double numero2 = Double.parseDouble(operacio2.getText().toString());

            double suma = numero1 + numero2;

            resultat.setText(String.valueOf(suma));
        });


        btnResta.setOnClickListener(v -> {

            double numero1 = Double.parseDouble(operacio1.getText().toString());
            double numero2 = Double.parseDouble(operacio2.getText().toString());

            double resta = numero1 - numero2;

            resultat.setText(String.valueOf(resta));
        });


        btnMultiplicar.setOnClickListener(v -> {

            double numero1 = Double.parseDouble(operacio1.getText().toString());
            double numero2 = Double.parseDouble(operacio2.getText().toString());

            double multiplicacio = numero1 * numero2;

            resultat.setText(String.valueOf(multiplicacio));
        });

        btnDividir.setOnClickListener(v -> {

            double numero1 = Double.parseDouble(operacio1.getText().toString());
            double numero2 = Double.parseDouble(operacio2.getText().toString());
            double divisio;

            if (numero2 == 0.0) {
                divisio = Double.POSITIVE_INFINITY;
            } else {
                divisio = numero1 / numero2;
            }

            resultat.setText(String.valueOf(divisio));
        });







        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}